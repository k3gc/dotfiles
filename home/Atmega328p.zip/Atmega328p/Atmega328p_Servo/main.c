/*
   █████╗ ██╗   ██╗██████╗     ███████╗███████╗██████╗ ██╗   ██╗ ██████╗ 
  ██╔══██╗██║   ██║██╔══██╗    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔═══██╗
  ███████║██║   ██║██████╔╝    ███████╗█████╗  ██████╔╝██║   ██║██║   ██║
  ██╔══██║╚██╗ ██╔╝██╔══██╗    ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██║   ██║
  ██║  ██║ ╚████╔╝ ██║  ██║    ███████║███████╗██║  ██║ ╚████╔╝ ╚██████╔╝
  ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝   ╚═════╝ 

*                                                          by sofy_32
*/

#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "servo.h"
#include "ADC.h"


/*
╔══════════════════════════╗
║     PIN DEFINITIONS      ║
╚══════════════════════════╝ 
*/ 
volatile uint8_t *ddr = &DDRB;
volatile uint8_t *port = &PORTB;
volatile uint8_t mask = (1 << 2);

/*
╔═════════════════════════╗
║  FUNCTION DECLARATIONS  ║
╚═════════════════════════╝ 
*/
void init(void);
void UART_init(void);
void uart_write( unsigned char data );
void uart_Print(char *data );
char uart_Read(void);

char myBuffer = ' ';


int main(void)
{
	uint16_t pos = 0;

	cli();
	init();
	sei();

	uart_Print("Hello");
	
	while(1)
	{

		if (myBuffer == '1')
		{
			/* code */
			servo_setServo(0, 0);
		}

		if (myBuffer == '2')
		{
			/* code */
			servo_setServo(0, 115);
		}

		if (myBuffer == '3')
		{
			/* code */
			servo_setServo(0, 255);
		}
		

	}
}


void init(void)
{
	servo_init((uint8_t**)&ddr, (uint8_t**)&port, (uint8_t*)&mask, 1);
	ADC_init();
	UART_init();
}

void UART_init(void){
	//char datos[numeroBits] = "Hello Marlon\r";
	DDRB |= (1<<5);
	PORTB &= ~(1<<5);
	/* Configuración del USART como UART */

	// USART como UART
	UCSR0C &=~ (1<<UMSEL00);
	UCSR0C &=~ (1<<UMSEL01);

	// Paridad desactivada
	UCSR0C &=~ (1<<UPM00);
	UCSR0C &=~ (1<<UPM01);

	// Stops = 1
	UCSR0C &=~ (1<<USBS0);

	// Datos de 8 bits
	UCSR0C |=  (1<<UCSZ00);
	UCSR0C |=  (1<<UCSZ01);
	UCSR0B &=~ (1<<UCSZ02);
	
	// Calculo del baudrate
	UCSR0A |= (1<<U2X0);
	UBRR0 = (F_CPU/8/9600) - 1;

	UCSR0B |= (1<<TXEN0);
	UCSR0B |= (1<<RXEN0);

	UCSR0B |= (1<<RXCIE0);

}

void uart_write( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

void uart_Print(char *data ){
	while(*data){
		uart_write(*data);
		data++;
	}
}

char uart_Read(void){
	while( !(UCSR0A & (1<<RXC0)) );
	return UDR0;
}


ISR(USART_RX_vect)
{
	myBuffer = UDR0;

	while(!(UCSR0A & (1<<UDRE0)));
	UDR0 = myBuffer;
}

