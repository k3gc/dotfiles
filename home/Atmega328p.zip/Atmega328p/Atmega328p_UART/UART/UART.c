#include "UART.h"


void UART1_Init(unsigned long baudRate){
	
	
	unsigned int  MYUBRR = F_CPU/16/baudRate-1;
	
	/*Set baud rate */
	UBRR0H = (unsigned char)(MYUBRR>>8);
	UBRR0L = (unsigned char)MYUBRR;
	/*Enable receiver and transmitter */
	UCSR0B |= (1<<RXEN0)|(1<<TXEN0);
	/* Set frame format: 8data, 1stop bit */	UCSR0C = (3<<UCSZ00);
}

void UART1_Write( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

void UART1_Print(char *data ){
	while(*data){
		UART1_Write(*data);
		data++;
	}
}

char UART1_Read(void){
	while( !(UCSR0A & (1<<RXC0)) );
	return UDR0;
}

char UART1_Data_Rdy(void){
	
	if((UCSR0A &(1<<RXC0) ) == 0) return 0; else return 1;
}