/*
 * UART.h
 *
 * Created: 23/10/2022 05:46:50 p. m.
 *  Author: usuario
 */ 


#ifndef UART_H_
#define UART_H_


#define F_CPU 16000000UL
#include <avr/io.h>


void UART1_Init(unsigned long baudRate);
void UART1_Write(unsigned char data );
void UART1_Print(char *data );
char UART1_Read(void);
char UART1_Data_Rdy(void);



#endif /* UART_H_ */