/*
 * UART.c
 *
 * Created: 24/02/2019 17:23:54
 * Author : marlon
 */ 
#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


char myBuffer = ' ';
int myBuffer2 = 219;

void uart_init(void);
void uart_write(unsigned char data);
void Serial_print(char *data);


int main(void)
{
	
	DDRB |= (1<<5);
	PORTB &= ~(1<<5);

	cli();
	uart_init();
	sei();

    while (1) 
    {
		
		//while(!(UCSR0A & (1<<RXC0)));
		//myBuffer2 = UDR0;
		Serial_print("Hello World!\n");

		_delay_ms(1000);

		/*
		if (myBuffer == '1')
		{
			PORTB |= (1<<5);
		}

		if (myBuffer == '0')
		{			
			PORTB &= ~(1<<5);
		}
		*/
		
    }
}


void uart_write(unsigned char data)
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

void Serial_print(char *data)
{
	while(*data){
		uart_write(*data);
		data++;
	}
}

void uart_init(void)
{
	/* Configuración del USART como UART */

	// USART como UART
	UCSR0C &=~ (1<<UMSEL00);
	UCSR0C &=~ (1<<UMSEL01);

	// Paridad desactivada
	UCSR0C &=~ (1<<UPM00);
	UCSR0C &=~ (1<<UPM01);

	// Stops = 1
	UCSR0C &=~ (1<<USBS0);

	// Datos de 8 bits
	UCSR0C |=  (1<<UCSZ00);
	UCSR0C |=  (1<<UCSZ01);
	UCSR0B &=~ (1<<UCSZ02);
	
	// Calculo del baudrate
	UCSR0A |= (1<<U2X0);
	UBRR0 = (F_CPU/8/9600) - 1;

	UCSR0B |= (1<<TXEN0);
	UCSR0B |= (1<<RXEN0);

	UCSR0B |= (1<<RXCIE0);
}

ISR(USART_RX_vect)
{
	myBuffer = UDR0;

	if (myBuffer == '1')
	{
		PORTB |= (1<<5);
	}

	if (myBuffer == '0')
	{			
		PORTB &= ~(1<<5);
	}

	//while(!(UCSR0A & (1<<UDRE0)));
	//UDR0 = myBuffer;
}
