#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <stdio.h>
#include <avr/io.h>
#include <avr/delay.h>
#include <avr/pgmspace.h>

#include "SSD1306.h"
#include "i2c.h"

uint8_t val = 0;

int main(void) {
	  
    OLED_Init();  //initialize the OLED
    OLED_Clear(); //clear the display (for good measure)
    
    OLED_SetCursor(0, 0);        //set the cursor position to (0, 0)
    OLED_Printf("Hello World!"); //Print out some text
    
    _delay_ms(1000);

    OLED_Clear();

    while (1) {

        OLED_SetCursor(0, 32);
        OLED_Printf("Menu Config");
        OLED_SetCursor(2, 0);
        OLED_Printf("Option_1: Intruccion\n\nOption_2: Intruccion\n\nOption_3: Intruccion");
        _delay_ms(10);

    }
    
    return 0; // never reached
}

