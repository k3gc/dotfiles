/*
 * Created: 2/02/2023 2:43
 * Author : sof1
 */
#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


int main(void)
{

    DDRB |= (1<<0);
    DDRB |= (1<<1);

    PORTB |= (1<<0);
    PORTB &= ~(1<<1);

    TCCR0A = 0x00;
    TCCR0B = 0x02;

    TIMSK0 |= (1<<TOIE0);

    sei();

    TCNT0 = 235;

	while(1)
	{
	}

}


ISR(TIMER0_OVF_vect) {

    PORTB ^= (1<<0);
    PORTB ^= (1<<1);
    TCNT0 = 235;

}
