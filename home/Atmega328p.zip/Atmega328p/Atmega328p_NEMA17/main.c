/*
*
   █████╗ ██╗   ██╗██████╗      ██████╗  ██████╗ ██████╗ ██████╗ ███████╗
  ██╔══██╗██║   ██║██╔══██╗    ██╔════╝ ██╔════╝██╔═══██╗██╔══██╗██╔════╝
  ███████║██║   ██║██████╔╝    ██║  ███╗██║     ██║   ██║██║  ██║█████╗
  ██╔══██║╚██╗ ██╔╝██╔══██╗    ██║   ██║██║     ██║   ██║██║  ██║██╔══╝
  ██║  ██║ ╚████╔╝ ██║  ██║    ╚██████╔╝╚██████╗╚██████╔╝██████╔╝███████╗
  ╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝     ╚═════╝  ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝

*                                                        by sofy_32
*/

#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <stdint.h>
#include <stdbool.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


/*
╔══════════════════════════╗
║     PIN DEFINITIONS      ║
╚══════════════════════════╝ 
*/ 
#define STEPS    PINB0
#define DIR      PINB1
#define EN       PINB2
#define STOP     PINB5
#define REST     PIND2

/*
╔══════════════════════════╗
║   STEPPER MOTOR MACROS   ║
╚══════════════════════════╝ 
*/
#define FAST_SPEED     400
#define NORMAL_SPEED   700

#define SPEED        NORMAL_SPEED

#define	ENABLE()	 PORTB &= ~(1<<EN)
#define	DISABLED()	 PORTB |= (1<<EN)

#define	DIRPOS()	 PORTB |= (1<<DIR)
#define	DIRNEG()	 PORTB &= ~(1<<DIR)

/*
╔═════════════════════════╗
║     GCODE COMMANDS      ║
╚═════════════════════════╝ 
*/
#define	CMD_RAPID_LINEAR_MOVE	"G0"
#define	CMD_LINEAR_MOVE			"G1"
#define	CMD_CW_ARC				"G2"
#define	CMD_CCW_ARC				"G3"
#define	CMD_MOVE_TO_ORIGIN		"G28"
#define	CMD_SET_POSITION		"G92"
#define CMD_SPINDLE_ON          "M3"
#define CMD_SPINDLE_OFF         "M5"
#define	CMD_GET_CURRENT_POS		"M114"

/*
╔═════════════════════════╗
║        COMMANDS         ║
╚═════════════════════════╝ 
*/   
#define	CMD_SAVE				"SAVE"
#define CMD_JOGXP               "JXP"
#define CMD_JOGXM               "JXM"
#define CMD_JOGYP               "JYP"
#define CMD_JOGYM               "JYM"
#define CMD_JOGZP               "JZP"
#define CMD_JOGZM               "JZM"
#define CMD_SET_FEED_RATE       "SFR"

/*
╔═════════════════════════╗
║   variable definition   ║
╚═════════════════════════╝ 
*/
uint16_t i = 0;
char myBuffer = ' ';
bool start;

/*
╔═════════════════════════╗
║  FUNCTION DECLARATIONS  ║
╚═════════════════════════╝ 
*/
void uart_init(void);
void uart_write(unsigned char data);
void Serial_print(char *data);
void motor_run();
void motor_step(uint16_t step);
void motor_test(void);
void interrut_init(void);


int main(void)
{

    /* Initialize variables */
    start = false;

    /* global pull-up enable */
    MCUCR &= ~(1<<PUD); 

    /* set pin directions */
    DDRB |= (1<<EN);
    DDRB |= (1<<STEPS);
    DDRB |= (1<<DIR);
    DDRB |= (1<<STOP);
    DDRD &=~ (1<<REST);

    PORTB &= ~(1<<STOP);
    PORTD |= (1<<REST); // pull-up enable

    /* Initialize */
    cli();
    uart_init();
    interrut_init();
    sei();

    //TCNT0 = 255;

    Serial_print("iniciando Sistema\n");
    _delay_ms(800);

    Serial_print("Comprobando..");
    motor_test();
    _delay_ms(100);

    Serial_print("Listo!\n");
    _delay_ms(100);

    while (1)
    {
        motor_run();
        //motor_test();
	    //_delay_ms(5000);

    }

}


void motor_run(){

    ENABLE();
    while (start)
        {
            /* 400min ==> 1000max*/
            PORTB |= (1 << STEPS);
            _delay_us(SPEED);
            PORTB &= ~(1 << STEPS);
            _delay_us(SPEED);
            
        }
}

void motor_step(uint16_t step){

    for (i = 0; i < step; i++)
    {
        /* 400min ==> 1000max*/
        PORTB |= (1 << STEPS);
        _delay_us(SPEED);
        PORTB &= ~(1 << STEPS);
        _delay_us(SPEED);

    }

}

void motor_test(void){

    uart_write('.');
    PORTB &= ~(1<<STEPS);
    DIRPOS();
    motor_step(1000);
    uart_write('.');

    _delay_ms(1000);

    uart_write('.');
    PORTB &= ~(1<<STEPS);
    DIRNEG();
    motor_step(1000);
    uart_write('.');

    _delay_ms(1000);
    uart_write('\n');

}

void uart_write(unsigned char data)
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE0)) );
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

void Serial_print(char *data)
{
	while(*data){
		uart_write(*data);
		data++;
	}
}

void uart_init(void)
{
	/* Configuración del USART como UART */

	// USART como UART
	UCSR0C &=~ (1<<UMSEL00);
	UCSR0C &=~ (1<<UMSEL01);

	// Paridad desactivada
	UCSR0C &=~ (1<<UPM00);
	UCSR0C &=~ (1<<UPM01);

	// Stops = 1
	UCSR0C &=~ (1<<USBS0);

	// Datos de 8 bits
	UCSR0C |=  (1<<UCSZ00);
	UCSR0C |=  (1<<UCSZ01);
	UCSR0B &=~ (1<<UCSZ02);
	
	// Calculo del baudrate
	UCSR0A |= (1<<U2X0);
	UBRR0 = (F_CPU/8/9600) - 1;

	UCSR0B |= (1<<TXEN0);
	UCSR0B |= (1<<RXEN0);

	UCSR0B |= (1<<RXCIE0);
}

void interrut_init(void){

    EICRA &=~ (1<<ISC00);
	EICRA |= (1<<ISC01);

	EIMSK |= (1<<INT0);

}

ISR(USART_RX_vect)
{
	myBuffer = UDR0;

	if (myBuffer == '1')
	{
        start = true;
        PORTB &= ~(1<<STOP);
	}

	if (myBuffer == '0')
	{			
        start = false;
        PORTB |= (1<<STOP);
	}

	//while(!(UCSR0A & (1<<UDRE0)));
	//UDR0 = myBuffer;
}

ISR(INT0_vect)
{
    if (!(PIND & (1<<REST)))
    {
        while(!(PIND & (1<<REST)));
        DISABLED();
        start = !start;
    }

}

