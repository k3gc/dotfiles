#include "myUIlib.h"
#include "myUARTlib.h"
#include "ASCIIdefinitions.h"
#include <string.h>

// edit mar_4_2018: removed echo feature and delete char feature
// from UI_get

uint8_t UI_get(char *buf, uint8_t bufLen)
{
	// received character
	char c;
	
	// character index
	uint8_t charIndex = 0;
	
	// receive character
	while((c = UART_getc()))
	{
		if(charIndex <= bufLen)
		{
			if(c == ASCII_CARRIAGERETURN)
			{
				// null terminate buffer
				buf[charIndex] = ASCII_NUL;
				
				// return success
				return UI_rcvSuccess;
			}
			else
			{
				// store character in buffer
				buf[charIndex] = c;
				
				// increment character index
				charIndex++;
			}
		}
		else
		{
			if(c == ASCII_CARRIAGERETURN)
			{
				// null terminate buffer
				buf[bufLen] = ASCII_NUL;
				
				// return success
				return UI_rcvOverflow;
			}
		}
	}
	
	// function should not reach this point, return error
	return UI_rcvError;
}
