#ifndef ASCII_DEFINITIONS_H
#define ASCII_DEFINITIONS_H

/***** ASCII Control Characters *****/
#define ASCII_NUL				0	// Null char
#define ASCII_SOH				1	// Start of Heading
#define ASCII_STX				2	// Start of Text
#define ASCII_ETX				3	// End of Text
#define ASCII_EOT				4	// End of Transmission
#define ASCII_ENQ				5	// Enquiry
#define ASCII_ACK				6	// Acknowledgment
#define ASCII_BEL				7	// Bell
#define ASCII_BACKSPACE			8	// Back Space
#define ASCII_TAB				9	// Horizontal Tab
#define ASCII_LINEFEED			10	// Line Feed
#define ASCII_VERTTAB			11	// Vertical Tab
#define ASCII_FORMFEED			12	// Form Feed
#define ASCII_CARRIAGERETURN	13	// Carriage Return
#define ASCII_SO				14	// Shift Out / X-On
#define ASCII_SI				15	// Shift In / X-Off
#define ASCII_DLE				16	// Data Line Escape
#define ASCII_DC1				17	// Device Control 1 (oft. XON)
#define ASCII_DC2				18	// Device Control 2
#define ASCII_DC3				19	// Device Control 3 (oft. XOFF)
#define ASCII_DC4				20	// Device Control 4
#define ASCII_NAK				21	// Negative Acknowledgement
#define ASCII_SYN				22	// Synchronous Idle
#define ASCII_ETB				23	// End of Transmit Block
#define ASCII_CAN				24	// Cancel
#define ASCII_EM				25	// End of Medium
#define ASCII_SUB				26	// Substitute
#define ASCII_ESC				27	// Escape
#define ASCII_FS				28	// File Separator
#define ASCII_GS				29	// Group Separator
#define ASCII_RS				30	// Record Separator
#define ASCII_US				31	// Unit Separator
#define ASCII_SPACE				32	// Space

#endif