#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdlib.h>
#include <string.h>
#include <avr/eeprom.h>
#include "myUARTlib.h"
#include "myUIlib.h"
#include "ASCIIdefinitions.h"

#define	MAIN_DEBUG			0

#define UART_BAUDRATE 		57600

/** PIN DEFINITIONS **/
#define	XSTEP				PINB0
#define XDIR				PINB1
#define YSTEP				PINB2

#define ZDIR				PINC3
#define ZSTEP				PINC4
#define	YDIR				PINC5

#define BUSY_PIN            PIND2
#define RTS                 PIND3
#define SPINDLE_PWM         PIND5
#define SPINDLE_ENABLE_PIN  PIND6

#define READ_RTS()          PIND & (1 << RTS)

/** STEPPER MOTOR MACROS **/
#define	XDIRPOS()			PORTB |= (1 << XDIR)
#define	XDIRNEG()			PORTB &= ~(1 << XDIR)

#define	YDIRNEG()			PORTC |= (1 << YDIR)
#define	YDIRPOS()			PORTC &= ~(1 << YDIR)

#define ZDIRPOS()			PORTC |= (1 << ZDIR)
#define ZDIRNEG()			PORTC &= ~(1 << ZDIR)

#define STEP_X()            PORTB |= (1 << XSTEP); TIME_DELAY(); PORTB &= ~(1 << XSTEP); TIME_DELAY()
#define STEP_Y()            PORTB |= (1 << YSTEP); TIME_DELAY(); PORTB &= ~(1 << YSTEP); TIME_DELAY()
#define STEP_Z()            PORTC |= (1 << ZSTEP); TIME_DELAY(); PORTC &= ~(1 << ZSTEP); TIME_DELAY()

#define STEP_X_RAPID()      PORTB |= (1 << XSTEP); TIME_DELAY(); PORTB &= ~(1 << XSTEP); TIME_DELAY()
#define STEP_Y_RAPID()      PORTB |= (1 << YSTEP); TIME_DELAY(); PORTB &= ~(1 << YSTEP); TIME_DELAY()
#define STEP_Z_RAPID()      PORTC |= (1 << ZSTEP); TIME_DELAY(); PORTC &= ~(1 << ZSTEP); TIME_DELAY()

#define ENABLE_SPINDLE()    PORTD &= ~(1 << SPINDLE_ENABLE_PIN)
#define DISABLE_SPINDLE()   PORTD |= (1 << SPINDLE_ENABLE_PIN)

/** UART MACROS **/
#define SET_BUSY_FLAG()     PORTD |= (1 << BUSY_PIN)
#define CLR_BUSY_FLAG()     PORTD &= ~(1 << BUSY_PIN)

/** BUFFER LENGTHS **/
#define	RCVBUFLEN			50
#define CMDBUFLEN			50
#define ARGBUFLEN			50
#define XBUFLEN				50
#define YBUFLEN				50
#define ZBUFLEN				50
#define IBUFLEN				50
#define JBUFLEN				50
#define PBUFLEN             50

/** GCODE COMMANDS **/
#define	CMD_RAPID_LINEAR_MOVE	"G0"
#define	CMD_LINEAR_MOVE			"G1"
#define	CMD_CW_ARC				"G2"
#define	CMD_CCW_ARC				"G3"
#define	CMD_MOVE_TO_ORIGIN		"G28"
#define	CMD_SET_POSITION		"G92"
#define CMD_SPINDLE_ON          "M3"
#define CMD_SPINDLE_OFF         "M5"
#define	CMD_GET_CURRENT_POS		"M114"

/** MY COMMANDS **/
#define	CMD_SAVE				"SAVE"
#define CMD_JOGXP               "JXP"
#define CMD_JOGXM               "JXM"
#define CMD_JOGYP               "JYP"
#define CMD_JOGYM               "JYM"
#define CMD_JOGZP               "JZP"
#define CMD_JOGZM               "JZM"
#define CMD_SET_FEED_RATE       "SFR"

/** RESPONSE DEFINITIONS **/
#define RES_CMD_ACK             "ACK\n"
#define RES_CMD_DONE            "DONE\n"
#define RES_CMD_NACK            "NACK\n"
#define	RES_CMD_BUSY			"BUSY\n"

#define DOARC_ERROR				0xFF
#define DOARC_SUCCESS			0x00

#define	promLowerXaddr			(uint8_t*) 0
#define	promUpperXaddr			(uint8_t*) 1
#define	promLowerYaddr			(uint8_t*) 2
#define	promUpperYaddr			(uint8_t*) 3
#define	promChkSumAddr			(uint8_t*) 4

#define	DEFAULTX				0
#define DEFAULTY				0
#define DEFAULTZ				0

/** POSITION DEFINITIONS **/
#define	ORIGINX				    0
#define	ORIGINY				    0
#define	CW_DIR				    1
#define	CCW_DIR				    0

#define SPEED_RAPID             1
#define SPEED_NORMAL            0

#define	CMD_SUCCESS			    1
#define	CMD_ERROR			    0

#define PARSE_SUCCESS           1
#define PARSE_ERROR             0
#define PARAM_NOT_FOUND         2

/** TIMER MACROS **/
#define MAX_SPEED_XY            1500
#define MAX_SPEED_Z             2500
#define DEFAULT_SPEED_XY        2000
#define DEFAULT_SPEED_Z         3500
#define RESET_CLK()             TCNT1 = 0x0000
#define SET_OCR(x)              OCR1AH = (uint8_t)(x >> 8); OCR1AL = (uint8_t)(x & 0x00FF)
#define ENA_COMPA_INT()         TIMSK1 |= (1 << OCIE1A)
#define DIS_COMPA_INT()         TIMSK1 &= ~(1 << OCIE1A)

int16_t	currentX	= 0;
int16_t	currentY	= 0;
int16_t	currentZ	= 0;

char rcvBuf[RCVBUFLEN];
volatile uint8_t wait = 0;
volatile uint16_t xySpeed = DEFAULT_SPEED_XY;
volatile uint16_t zSpeed = DEFAULT_SPEED_Z;

/** FUNCTION DECLARATIONS **/
uint8_t parseCmd(void);
uint8_t parseParam(char *argBuf, char param, int16_t *cmdP);
void doLine(int16_t x, int16_t y, uint8_t speed);
void doLineZ(int16_t z, uint8_t speed);
uint8_t doArc(int32_t stopX, int32_t stopY, int32_t xOffset, int32_t yOffset, uint8_t dir);
void getDir(uint8_t binrep, int32_t *x0, int32_t *y0);
void loadCoor(int16_t *currentX, int16_t *currentY);
void saveCoor(int16_t *currentX, int16_t *currentY);
void initTimer1(void);
void TIME_DELAY(void);

ISR(TIMER1_COMPA_vect)
{
    // clear wait flag
    wait = 0;
}

int main(void)
{	
    // Initialize variables
    uint8_t rcvIdx;
    char c;

	// Initialize UART with interrupts
    UART_init(UART_BAUDRATE);
	
	// load last saved coordinates from EEPROM
    loadCoor(&currentX, &currentY);
	
	// set pin directions
	DDRB |= (1 << XSTEP);
	DDRB |= (1 << XDIR);
	DDRB |= (1 << YSTEP);
	DDRC |= (1 << YDIR);
	DDRC |= (1 << ZSTEP);
	DDRC |= (1 << ZDIR);
    DDRD |= (1 << BUSY_PIN);
    DDRD |= (1 << SPINDLE_ENABLE_PIN);
    DDRD |= (1 << SPINDLE_PWM);
    DDRD &= ~(1 << RTS);

    // set spindle timer parameters
    DISABLE_SPINDLE();
    PRR &= (1 << PRTIM0);
    TCCR0A |= (1 << COM0B1) | (1 << COM0B0) | (1 << WGM00);
    TCCR0B |= (1 << CS00);
    OCR0B = 30;

    // initialize TIMER1
    initTimer1();

    // enable interrupts
    sei();

    while(1)
    {
        // Set receive index to beginning of buffer
        rcvIdx = 0;

        // Get character from UART
        c = UART_getc();

        // While newline char is not received
        while(c != 0x0A)
        {
            // Add character to receive buffer
            rcvBuf[rcvIdx] = c;
            rcvIdx++;

            // Receive next character
            c = UART_getc();
        }

        // Null terminate buffer
        rcvBuf[rcvIdx] = 0;

        // Set busy flag while command is being parsed
        SET_BUSY_FLAG();

        //UART_puts(rcvBuf);

        if(parseCmd() != CMD_SUCCESS)
        {
            UART_puts(RES_CMD_NACK);
        }

        // Clear busy flag
        CLR_BUSY_FLAG();
    }
}

uint8_t parseParam(char *argBuf, char param, int16_t *cmdP)
{
    char *arg_pStart, *arg_pStop;
    char pBuf[PBUFLEN];
    uint8_t pLen = 0;

    arg_pStart = strchr(argBuf, param);
    
    // if 'X' found
    if (arg_pStart != NULL)
    {
        arg_pStop = arg_pStart;
        
        // while current char is not a space, or null
        while ((*arg_pStop != ' ') && (*arg_pStop != ASCII_NUL))
        {
            // increment to next char
            arg_pStop++;
            
            // calculate length
            pLen = (uint8_t)(arg_pStop - argBuf);
            
            // if end of buffer has been reached
            if (pLen > ARGBUFLEN)
            {
                return PARSE_ERROR;
            }
        }
        
        // copy param value into param buffer
        strncpy(pBuf, arg_pStart+1, pLen);
        
        // null terminate buffer
        pBuf[pLen] = ASCII_NUL;
        
        *cmdP = atoi(pBuf);
        return PARSE_SUCCESS;
    }
    else
    {
        return PARAM_NOT_FOUND;
    }
}

uint8_t parseCmd(void)
{
	// buffers
	char cmdBuf[CMDBUFLEN], argBuf[ARGBUFLEN];
	char *argP;
	uint8_t cmdLen, ret;
	int16_t cmdX, cmdY, cmdZ, cmdI, cmdJ, cmdF;

    // set default values for commands
    cmdX = currentX;
    cmdY = currentY;
    cmdZ = currentZ;
    cmdF = xySpeed;
	
	// search for space in received characters
	argP = strchr(rcvBuf, ' ');

	// if no space found (no args)
	if(argP == NULL)
	{
		// copy receive buffer into command buffer
		strcpy(cmdBuf, rcvBuf);
		cmdLen = strlen(cmdBuf);
		cmdBuf[cmdLen] = ASCII_NUL;
		*argBuf = ASCII_NUL;
	}
	// if space found (args)
	else
	{
		// calculate length of command
		cmdLen = (uint8_t)(argP - rcvBuf);

		// copy command into command buffer
		strncpy(cmdBuf, rcvBuf, cmdLen);
		cmdBuf[cmdLen] = 0; // null terminate command
		
		// copy argument into argument buffer
		argP++; // increment past space
		strcpy(argBuf, argP);
	}
	/**********************************/
	/* If CMD = Rapid Linear Move (G0)*/
	/**********************************/
	if (strcmp(cmdBuf, CMD_RAPID_LINEAR_MOVE) == 0)
	{
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;
		
        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded y
        if(parseParam(argBuf, 'Y', &cmdY) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded z
        if(parseParam(argBuf, 'Z', &cmdZ) == PARSE_ERROR)
            return CMD_ERROR;

        // ack command
        UART_puts(RES_CMD_ACK);

		// do line
		doLine(cmdX, cmdY, SPEED_RAPID);
		doLineZ(cmdZ, SPEED_RAPID);
			
        // return success
		return CMD_SUCCESS;
	}
	/****************************/
	/* If CMD = Linear Move (G1)*/
	/****************************/
    else if (strcmp(cmdBuf, CMD_LINEAR_MOVE) == 0)
	{
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;
		
        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded y
        if(parseParam(argBuf, 'Y', &cmdY) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded z
        if(parseParam(argBuf, 'Z', &cmdZ) == PARSE_ERROR)
            return CMD_ERROR;	

        // get commanded feed rate
        ret = parseParam(argBuf, 'F', &cmdF);
        if(ret == PARSE_ERROR)
        {
            return CMD_ERROR;	
        }
        else if (ret == PARSE_SUCCESS)
        {
            xySpeed = cmdF;
        }

        // ack command
        UART_puts(RES_CMD_ACK);

		// do line
		doLine(cmdX, cmdY, SPEED_NORMAL);
		doLineZ(cmdZ, SPEED_NORMAL);
			
        // return success
		return CMD_SUCCESS;
	}
	/******************************/
	/* If CMD = Clockwise Arc (G2)*/
	/******************************/
	else if (strcmp(cmdBuf, CMD_CW_ARC) == 0)
	{
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			UART_puts(RES_CMD_NACK);
		
        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) != PARSE_SUCCESS)
            return CMD_ERROR;

        // get commanded y
        if(parseParam(argBuf, 'Y', &cmdY) != PARSE_SUCCESS)
            return CMD_ERROR;

		// get commanded i
        if(parseParam(argBuf, 'I', &cmdI) != PARSE_SUCCESS)
            return CMD_ERROR;

        // get commanded j
        if(parseParam(argBuf, 'J', &cmdJ) != PARSE_SUCCESS)
            return CMD_ERROR;

        // ack cmd
        UART_puts(RES_CMD_ACK);

        // do commanded arc
		if(doArc((int32_t)cmdX, (int32_t)cmdY, (int32_t)cmdI, (int32_t)cmdJ, CW_DIR) != DOARC_SUCCESS)
			return CMD_ERROR;
        
        // return success
        return CMD_SUCCESS;
	}
	/**************************************/
	/* If CMD = Counter-Clockwise Arc (G3)*/
	/**************************************/
	else if(strcmp(cmdBuf, CMD_CCW_ARC) == 0)
	{
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;

        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) != PARSE_SUCCESS)
            return CMD_ERROR;

        // get commanded y
        if(parseParam(argBuf, 'Y', &cmdY) != PARSE_SUCCESS)
            return CMD_ERROR;

		// get commanded i
        if(parseParam(argBuf, 'I', &cmdI) != PARSE_SUCCESS)
            return CMD_ERROR;

        // get commanded j
        if(parseParam(argBuf, 'J', &cmdJ) != PARSE_SUCCESS)
            return CMD_ERROR;

	    // ack cmd
        UART_puts(RES_CMD_ACK);	

        // do commanded arc
		if(doArc((int32_t)cmdX, (int32_t)cmdY, (int32_t)cmdI, (int32_t)cmdJ, CCW_DIR) != DOARC_SUCCESS)
			return CMD_ERROR;

        // return success
		return CMD_SUCCESS;
	}
	/***************************/
	/* If CMD = Spindle On (M3)*/
	/***************************/
    else if(strcmp(cmdBuf, CMD_SPINDLE_ON) == 0)
    {
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;

		// get commanded spindle
        if(parseParam(argBuf, 'S', &cmdI) != PARSE_SUCCESS)
            return CMD_ERROR;

        // ack cmd
        UART_puts(RES_CMD_ACK);

        // set spindle speed
        OCR0B = cmdI;

        // enable spindle
        ENABLE_SPINDLE();

        // return success
        return CMD_SUCCESS;
    }
	/****************************/
	/* If CMD = Spindle Off (M5)*/
	/****************************/
    else if(strcmp(cmdBuf, CMD_SPINDLE_OFF) == 0)
    {
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // disable spindle
        DISABLE_SPINDLE();

        // return success
        return CMD_SUCCESS;
    }
	/***************************************/
	/* If CMD = Get Current Position (M114)*/
	/***************************************/
	else if(strcmp(cmdBuf, CMD_GET_CURRENT_POS) == 0)
	{
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // send x coordinates
		UART_puts("X");
		UART_send16(currentX);
        UART_putc(' ');

        // send y coordinates
		UART_puts("Y");
		UART_send16(currentY);
        UART_putc(' ');

        // send z coordinates
		UART_puts("Z");
		UART_send16(currentZ);
        UART_putc('\n');
        
        // return success
        return CMD_SUCCESS;
	}
	/********************************/
	/* If CMD = Move to Origin (G28)*/
	/********************************/
	else if (strcmp(cmdBuf, CMD_MOVE_TO_ORIGIN) == 0)
	{
        // ack command
        UART_puts(RES_CMD_ACK);

        // move to origin
		doLine(ORIGINX, ORIGINY, SPEED_RAPID);

        // return success
		return CMD_SUCCESS;
	}
	/******************************/
	/* If CMD = Set Position (G92)*/
	/******************************/
	else if (strcmp(cmdBuf, CMD_SET_POSITION) == 0)
	{	
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;

        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded y
        if(parseParam(argBuf, 'Y', &cmdY) == PARSE_ERROR)
            return CMD_ERROR;

        // get commanded z
        if(parseParam(argBuf, 'Z', &cmdZ) == PARSE_ERROR)
            return CMD_ERROR;	
		
        // ack cmd
        UART_puts(RES_CMD_ACK);

		// set new position
		currentX = cmdX;
		currentY = cmdY;
		currentZ = cmdZ;

        // return success
		return CMD_SUCCESS;
	
	}
	else if (strcmp(cmdBuf, CMD_SAVE) == 0)
	{
        UART_puts(RES_CMD_ACK);
		saveCoor(&currentX, &currentY);
        
        return CMD_SUCCESS;
	}
    /********************/
    /* JOGX POSITIVE ****/
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGXP) == 0)
    {
        // set direction positive
		XDIRPOS();

        // set speed
        SET_OCR(xySpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_X_RAPID();
			currentX++;
            state = PIND;
        }

        // send x coordinates
		UART_puts("X");
		UART_send16(currentX);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }    
    /********************/
    /* JOGX NEGATIVE */
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGXM) == 0)
    {
        // set direction positive
		XDIRNEG();

        // set speed
        SET_OCR(xySpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_X_RAPID();
			currentX--;
            state = PIND;
        }

        // send x coordinates
		UART_puts("X");
		UART_send16(currentX);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }
    /********************/
    /* JOGY POSITIVE */
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGYP) == 0)
    {
        // set direction positive
		YDIRPOS();

        // set speed
        SET_OCR(xySpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_Y_RAPID();
			currentY++;
            state = PIND;
        }

        // send y coordinates
		UART_puts("Y");
		UART_send16(currentY);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }    
    /********************/
    /* JOGY NEGATIVE */
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGYM) == 0)
    {
        // set direction positive
		YDIRNEG();

        // set speed
        SET_OCR(xySpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_Y_RAPID();
			currentY--;
            state = PIND;
        }

        // send y coordinates
		UART_puts("Y");
		UART_send16(currentY);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }
    /********************/
    /* JOGZ POSITIVE */
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGZP) == 0)
    {
        // set direction positive
		ZDIRPOS();

        // set speed
        SET_OCR(zSpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_Z_RAPID();
			currentZ++;
            state = PIND;
        }

        // send z coordinates
		UART_puts("Z");
		UART_send16(currentZ);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }    
    /********************/
    /* JOGZ NEGATIVE */
    /********************/
    else if(strcmp(cmdBuf, CMD_JOGZM) == 0)
    {
        // set direction positive
		ZDIRNEG();

        // set speed
        SET_OCR(zSpeed);

        // get state of PIND
        uint8_t state = PIND;
        
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // continue while RTS pin is high
        while(state & (1 << RTS))
        {
            STEP_Z_RAPID();
			currentZ--;
            state = PIND;
        }

        // send z coordinates
		UART_puts("Z");
		UART_send16(currentZ);
        UART_putc('\n');

        // return success
        return CMD_SUCCESS;
    }
    /*****************/
    /* SET FEED RATE */
    /*****************/
    else if(strcmp(cmdBuf, CMD_SET_FEED_RATE) == 0)
    {
		// if no arguments rcvd
		if (*argBuf == ASCII_NUL)
			return CMD_ERROR;

        // get commanded x
        if(parseParam(argBuf, 'X', &cmdX) == PARSE_SUCCESS)
            xySpeed = cmdX;

        // get commanded z
        if(parseParam(argBuf, 'Z', &cmdZ) == PARSE_SUCCESS)
            zSpeed = cmdZ;
		
        // ack cmd
        UART_puts(RES_CMD_ACK);

        // return success
		return CMD_SUCCESS;
    }
	else
	{
        /* UNCOMMENT TO REPEAT UNKNOWN COMMANDS
        char *temp = cmdBuf;
        
        while(*temp > 0)
        {
        	UART_writeHex(*temp);
        	temp++;
        }*/
        
        // return error
        return CMD_ERROR;
	}
}

void initTimer1(void)
{
    // enable timer1
    PRR &= ~(1 << PRTIM1);
    
    // set normal port operation
    TCCR1A &= ~((1 << COM1A1) | (COM1A0));

    // set ctc mode, no clock prescale
    TCCR1B |= (1 << WGM12) | (1 << CS10);

    // set match value
    SET_OCR(DEFAULT_SPEED_XY);
}

void TIME_DELAY(void)
{
    // set wait flag
    wait = 1;

    // reset clock
    RESET_CLK();

    // enable TIMER1 compare A match interrupt
    ENA_COMPA_INT();

    // wait for time to expire
    while(wait);

    // disable TIMER1 compare A match interrupt
    DIS_COMPA_INT();
}

void doLine(int16_t stopX, int16_t stopY, uint8_t speed)
{
    if (speed == SPEED_RAPID)
    {
        SET_OCR(MAX_SPEED_XY);
    }
    else
    {
        SET_OCR(xySpeed);
    }

	int16_t x0 = 0;
	int16_t y0 = 0;

	int16_t dx = stopX - currentX;

	if (dx > 0)
	{
		// set dir x +
		XDIRPOS();
		x0 = 1;
	}
	else
	{
		// set dir x -
		XDIRNEG();
		x0 = -1;
	}

	int16_t dy = stopY - currentY;

	if (dy > 0)
	{
		// set dir y +
		YDIRPOS();
		y0 = 1;
	}
	else
	{
		// set dir y -
		YDIRNEG();
		y0 = -1;
	}

	dx = abs(dx);
	dy = abs(dy);

	int16_t fxy = dx - dy;
	int16_t x2 = 0;
	int16_t y2 = 0;

	while((x2 != dx) || (y2 != dy))
	{
		if (fxy > 0)
		{
			// step x
            STEP_X();
			x2++;
			currentX += x0;
			fxy = fxy - dy;
		}
		else
		{
            // step y
            STEP_Y();
			y2++;
			currentY += y0;
			fxy = fxy + dx;
		}
	}
}

void doLineZ(int16_t stopZ, uint8_t speed)
{
    if (speed == SPEED_RAPID)
    {
        SET_OCR(MAX_SPEED_Z);
    }
    else
    {
        SET_OCR(zSpeed);
    }

	int16_t dz = stopZ - currentZ;
	int16_t z0 = 0;

	if(dz == 0)
	{
		return;
	}
	else if(dz > 0)
	{
		ZDIRPOS();
		z0 = 1;
	}
	else
	{
		ZDIRNEG();
		z0 = -1;
	}

	while(currentZ != stopZ)
	{
        // step z
        STEP_Z();

		currentZ += z0;
	}
}

uint8_t doArc(int32_t stopX, int32_t stopY, int32_t xOffset, int32_t yOffset, uint8_t dir)
{
	int32_t x0 = 0;
	int32_t y0 = 0;
	int32_t arcOriginX, arcOriginY;
	uint8_t binrep;
    int32_t x2, y2, x3, y3;
	int32_t dx, dy, fxy;
	
	// calculate origin of arc
	arcOriginX = currentX + xOffset;
	arcOriginY = currentY + yOffset;

    // translate intermmediary points to circle centered at origin
    x2 = currentX - arcOriginX;
    y2 = currentY - arcOriginY;
    x3 = stopX - arcOriginX;
    y3 = stopY - arcOriginY;

    int32_t rr = xOffset*xOffset + yOffset*yOffset;
	
	do
	{
	
		fxy = x2*x2 + y2*y2 - rr;
		dx = 2*x2;
		dy = 2*y2;
	
		binrep = 0;
		if(dir > 0) binrep += 8;
		if(fxy >= 0) binrep += 4;
		if(dx >= 0) binrep += 2;
		if(dy >= 0) binrep += 1;
	
		getDir(binrep, &x0, &y0);
		
		if(x0 > 0)
		{
			// step x
			XDIRPOS();
			STEP_X();
			x2 += x0;
			currentX += x0;
		}
		else if(x0 < 0)
		{
			// step x
			XDIRNEG();
			STEP_X();
			x2 += x0;
			currentX += x0;
		}
		else if(y0 > 0)
		{
			// step y
			YDIRPOS();
			STEP_Y();
			y2 += y0;
			currentY += y0;
		}
		else if(y0 < 0)
		{
			// step y
			YDIRNEG();
			STEP_Y();
			y2 += y0;
			currentY += y0;
		}
		else
		{
			return DOARC_ERROR;
		}
	} 
	while((x2 != x3) || (y2 != y3));
	
	return DOARC_SUCCESS;
}

void getDir(uint8_t binrep, int32_t *x0, int32_t *y0)
{
	*x0 = 0;
	*y0 = 0;
	
	switch(binrep)
	{
		case 0:		*y0 = -1; 	break;
		case 1:		*x0 = -1; 	break;
		case 2:		*x0 = 1; 	break;
		case 3:		*y0 = 1; 	break;
		case 4:		*x0 = 1; 	break;
		case 5:		*y0 = -1; 	break;
		case 6:		*y0 = 1; 	break;
		case 7:		*x0 = -1; 	break;
		case 8:		*x0 = -1; 	break;
		case 9:		*y0 = 1; 	break;
		case 10:	*y0 = -1; 	break;
		case 11:	*x0 = 1; 	break;
		case 12:	*y0 = 1; 	break;
		case 13:	*x0 = 1; 	break;
		case 14:	*x0 = -1; 	break;
		case 15:	*y0 = -1; 	break;
	}
}

void loadCoor(int16_t *currentX, int16_t *currentY)
{
	uint8_t xLower, xUpper, yLower, yUpper, chkSum;
	
	xLower = eeprom_read_byte(promLowerXaddr);
	xUpper = eeprom_read_byte(promUpperXaddr);
	yLower = eeprom_read_byte(promLowerYaddr);
	yUpper = eeprom_read_byte(promUpperYaddr);
	chkSum = eeprom_read_byte(promChkSumAddr);
	
	if(chkSum != (xLower ^ xUpper ^ yLower ^ yUpper))
	{
		*currentX = DEFAULTX;
		*currentY = DEFAULTY;
		
		return;
	}
	
	#if EEPROM_DEBUG
	UART_puts("Xl: ");
	UART_sendU8(xLower);
	UART_puts("\r\nXu: ");
	UART_sendU8(xUpper);
	UART_puts("\r\nYl: ");
	UART_sendU8(xLower);
	UART_puts("\r\nYu: ");
	UART_sendU8(yUpper);
	UART_puts("\r\nCS: ");
	UART_writeHex(chkSum);
	UART_puts("\r\n");
	#endif
	
	*currentX = (((int16_t)xUpper) << 8) | (int16_t)(xLower);
	*currentY = (((int16_t)yUpper) << 8) | (int16_t)(yLower);
}

void saveCoor(int16_t *currentX, int16_t *currentY)
{
	uint8_t xLower, xUpper, yLower, yUpper, chkSum;
	
	xLower = (uint8_t) (0x00FF & *currentX);
	xUpper = (uint8_t) ((0xFF00 & *currentX) >> 8);
	yLower = (uint8_t) (0x00FF & *currentY);
	yUpper = (uint8_t) ((0xFF00 & *currentY) >> 8);
	
	chkSum = (xLower ^ xUpper ^ yLower ^ yUpper);
	
	#if EEPROM_DEBUG
	UART_puts("Xl: ");
	UART_sendU8(xLower);
	UART_puts("\r\nXu: ");
	UART_sendU8(xUpper);
	UART_puts("\r\nYl: ");
	UART_sendU8(xLower);
	UART_puts("\r\nYu: ");
	UART_sendU8(yUpper);
	UART_puts("\r\nCS: ");
	UART_writeHex(chkSum);
	UART_puts("\r\n");
	#endif
	
	eeprom_write_byte(promLowerXaddr, xLower);
	eeprom_write_byte(promUpperXaddr, xUpper);
	
	eeprom_write_byte(promLowerYaddr, yLower);
	eeprom_write_byte(promUpperYaddr, yUpper);
	
	eeprom_write_byte(promChkSumAddr, chkSum);
}
