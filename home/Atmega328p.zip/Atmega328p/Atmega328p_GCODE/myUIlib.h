#ifndef my_UI_lib_H
#define my_UI_lib_H

#include <avr/io.h>

#define	UI_DEBUG												0

/*******************************************************************
/						UI_getArg status codes					   /
*******************************************************************/
#define	UI_rcvSuccess											0x00
#define UI_rcvOverflow											0x55
#define UI_rcvError												0xFF

uint8_t UI_get(char *buf, uint8_t bufLen);

#endif