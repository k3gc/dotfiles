/*************************************************************************
* Title:    UART library
* Author:   Ryan Harmon
* File:     $Id: myUARTlib.c,v 1.2 2018/03/23
* Software: AVR-GCC 4.3.3
* Target:   ATmega328P
* Usage:    API compatible with UART Library myUARTlib.h v 1.2
*
* V 1.2 March 23 2018: Added UART_initi, initialization function which 
* enables receive interrupts
**************************************************************************/

#ifndef my_UART_lib_lite_h
#define my_UART_lib_lite_h

#include <avr/io.h>

/******** Precision Definitions ********/
#define UART_U8_MAX_DIGITS		3
#define UART_8_MAX_DIGITS		3
#define UART_U16_MAX_DIGITS		5
#define UART_16_MAX_DIGITS		5
#define UART_U32_MAX_DIGITS		10
#define UART_32_MAX_DIGITS		10
#define UART_BASE_10			10
#define UART_U8_MAX_BASE		100
#define UART_U16_MAX_BASE		10000
#define UART_SHIFT_DOWN_4(x)	x >> 4
#define UART_SHIFT_UP_4(x)		x << 4
#define UART_LOWER_BYTE_MASK	0x0F
#define UART_LOWER_BYTE(x)		(x & UART_LOWER_BYTE_MASK)
#define UART_UPPER_BYTE(x)		((x >> 4) & UART_LOWER_BYTE_MASK)
#define UART_8BIT_SIGN_MASK		0x80
#define UART_16BIT_SIGN_MASK	0x8000

/******** Function Declarations ********/
void UART_init(uint16_t baudRate);
void UART_initi(uint16_t baudRate);
void UART_putc(unsigned char data);
unsigned char UART_getc(void);
void UART_puts(char* charString);
void UART_writeHex(char n);
void UART_newLine(void);
void UART_sendU8(uint8_t val);
void UART_send8(int8_t val);
void UART_sendU16(uint16_t val);
void UART_send16(int16_t val);

#endif
