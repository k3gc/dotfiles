/*************************************************************************
* Title:    UART library
* Author:   Ryan Harmon
* File:     $Id: myUARTlib.c,v 1.0 2017/05/06
* Software: AVR-GCC 4.3.3
* Target:   ATmega328P
* Usage:    API compatible with UART Library myUARTlib.h
**************************************************************************/
#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <avr/io.h>
#include "myUARTlib.h"
#include "ASCIIdefinitions.h"

/*************************************************************************
 Initializes UART at input baud rate. Must be called to use UART.
*************************************************************************/
void UART_init(uint16_t baudRate)
{
	// activate UART in power reduction register
	PRR &= ~(1 << PRUSART0);
	
	// calculate baud rate
	baudRate = (((F_CPU/(baudRate*16UL))) - 1);
	
	// set rate
	UBRR0H = (unsigned char)(baudRate >> 8);
	UBRR0L = (unsigned char) baudRate;
	
	// Disable double transmission speed
	UCSR0A &= ~(1 << U2X0);
	
	// Enable reciever, transmitter, and rx interrupts
	UCSR0B |= (1 << RXEN0)|(1 << TXEN0);
	
	// Set frame format to 8 data
	UCSR0C |= (1 << UCSZ01)|(1 << UCSZ00);	
}

/*************************************************************************
 Sends character over UART
*************************************************************************/
void UART_putc(unsigned char data)
{
	// wait for empty transmit buffer
	while(!(UCSR0A & (1<<UDRE0)));	
	
	// send data to output register
	UDR0 = data;
}

/*************************************************************************
 Receives character over UART
*************************************************************************/
unsigned char UART_getc(void)
{
	// wait for data to be received
	while(!(UCSR0A & (1 << RXC0)));
	
	// get data to output register
	return UDR0;
}

/*************************************************************************
 Sends string over UART
*************************************************************************/
void UART_puts(char* charString)
{
	// iterate through string
	while(*charString > 0)
		// print character
		UART_putc(*charString++);
}

/*************************************************************************
 Sends newline over UART
*************************************************************************/
void UART_newLine(void)
{
	// print linefeed
	UART_putc(ASCII_LINEFEED);
	
	// print carriage return
	UART_putc(ASCII_CARRIAGERETURN);
}

/*************************************************************************
 Sends hex over UART
*************************************************************************/
void UART_writeHex(char n)
{
	// get upper byte
	if(UART_UPPER_BYTE(n) < UART_BASE_10)
	{
		// upper byte is digit, add to ASCII zero and print
		UART_putc('0' + UART_UPPER_BYTE(n));
	}
	else
	{
		// upper byte is character, add to ASCII A and print
		UART_putc('A' + UART_UPPER_BYTE(n) - UART_BASE_10);
	}
		
	// get lower byte
	n = UART_LOWER_BYTE(n);
	
	// get lower byte
	if(n < UART_BASE_10)
	{
		// lower byte is digit, add to ASCII zero and print
		UART_putc('0' + n);
	}
	else
	{
		// lower byte is character, add to ASCII A and print
		UART_putc('A' + n - UART_BASE_10);
	}
}

/*************************************************************************
 Sends unsigned 8 bit int over UART
*************************************************************************/
void UART_sendU8(uint8_t val)
{
	// max number of digits in 8 bit value
	uint8_t numDigits = UART_U8_MAX_DIGITS;
	
	// max order for 8 bit int is 100
	uint8_t currentBase = UART_U8_MAX_BASE;
	
	// set current digit to input value
	uint8_t currentDigit = val;
	
	// get rid of leading zeroes
	while((val/currentBase) == 0)
	{
		// reduce base by order of magnitude
		currentBase = currentBase/UART_BASE_10;
		
		// decrement number of digits in input
		numDigits--;
	}
	
	// calculate current digit
	currentDigit = val/currentBase;
	
	// iterate through each digit
	while(numDigits > 0)
	{
		// print current digit
		UART_putc('0' + currentDigit);
		
		// reduce value by order of magnitude
		val = val - currentDigit*currentBase;
		
		// reduce base by order of magnitude
		currentBase = currentBase/UART_BASE_10;
		
		// calculate current digit
		currentDigit = val/currentBase;
		
		// decrement number of digits in input
		numDigits--;
	}
}

/*************************************************************************
 Sends signed 8 bit int over UART
*************************************************************************/
void UART_send8(int8_t val)
{	
	// check for negative sign
	if(val & UART_8BIT_SIGN_MASK)
	{
		// print negative sign
		UART_putc('-');
		
		// convert from two's complement and send magnitude
		UART_sendU8(~val + 1);
	}
	else
	{
		// number is positive
		UART_sendU8(val);
	}
}

/*************************************************************************
 Sends unsigned 16 bit int over UART
*************************************************************************/
void UART_sendU16(uint16_t val)
{
	// max number of digits in 16 bit value
	uint16_t numDigits = UART_U16_MAX_DIGITS;
	
	// max order for 16 bit int is 10,000
	uint16_t currentBase = UART_U16_MAX_BASE;
	
	// set current digit to input value
	uint16_t currentDigit = val;
	
	// get rid of leading zeroes
	while((val/currentBase) == 0)
	{
		// reduce base by order of magnitude
		currentBase = currentBase/UART_BASE_10;
		
		// decrement number of digits in input
		numDigits--;
	}
	
	// calculate current digit
	currentDigit = val/currentBase;
	
	// iterate through each digit
	while(numDigits > 0)
	{
		// print current digit
		UART_putc('0' + currentDigit);
		
		// reduce value by order of magnitude
		val = val - currentDigit*currentBase;
		
		// reduce base by order of magnitude
		currentBase = currentBase/UART_BASE_10;
		
		// calculate current digit
		currentDigit = val/currentBase;
		
		// decrement number of digits in input
		numDigits--;
	}
}

/*************************************************************************
 Sends signed 16 bit int over UART
*************************************************************************/
void UART_send16(int16_t val)
{	
	// check for negative sign
	if(val & UART_16BIT_SIGN_MASK)
	{
		// print negative sign
		UART_putc('-');
		
		// convert from two's complement and send magnitude
		UART_sendU16(~val + 1);
	}
	else
	{
		// number is positive
		UART_sendU16(val);
	}
}