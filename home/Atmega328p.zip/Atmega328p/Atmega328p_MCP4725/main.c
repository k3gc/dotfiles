/*
 * Created: 21/01/2023 5:47
 * Author : sof1
 */ 
#ifndef __AVR_ATmega328P__
#define __AVR_ATmega328P__
#endif

#define F_CPU 16000000UL

#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "TWI.h"

#define MCP4725_I2CADDR_DEFAULT      (0x60) ///< Default i2c address
#define MCP4725_CMD_WRITEDAC         (0x40) ///< Writes data to the DAC
#define MCP4725_CMD_WRITEDACEEPROM   (0x60) ///< Writes data to the DAC and the EEPROM (persisting the assigned < value after reset)

void setVoltage(uint16_t output, bool writeEEPROM);

int main(void)
{

  cli();
  TWI_Init();
  sei();
	
  _delay_ms(1000);

	while(1)
	{

    setVoltage((1 * 4095) / 5, false);
    _delay_ms(2000);
    setVoltage((2 * 4095) / 5, false);
    _delay_ms(2000);
    setVoltage((3 * 4095) / 5, false);
    _delay_ms(2000);
    setVoltage((4 * 4095) / 5, false);
    _delay_ms(2000);
    setVoltage((5 * 4095) / 5, false);
    _delay_ms(2000);

	}
}

void setVoltage(uint16_t output, bool writeEEPROM){
  uint8_t packet[3];

  if (writeEEPROM) {
    packet[0] = MCP4725_CMD_WRITEDACEEPROM;
  } else {
    packet[0] = MCP4725_CMD_WRITEDAC;
  }
  packet[1] = output / 16;        // Upper data bits (D11.D10.D9.D8.D7.D6.D5.D4)
  packet[2] = (output % 16) << 4; // Lower data bits (D3.D2.D1.D0.x.x.x.x)

  while(TWI_startCond());
	while(TWI_sendAdrr(MCP4725_I2CADDR_DEFAULT, TWI_W));
	while(TWI_write(packet[0]));
	while(TWI_write(packet[1]));
  while(TWI_write(packet[2]));
	TWI_stopCond();

}

